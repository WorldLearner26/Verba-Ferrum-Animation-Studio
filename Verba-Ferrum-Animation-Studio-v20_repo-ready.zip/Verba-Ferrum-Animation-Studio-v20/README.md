# Verba & Ferrum Animation Studio v20

Real-character integration prototype using the v0.4 whole-hand architecture.

- 22-joint logical rig
- actual extracted character PNG layers
- Left Lead / Square / Right Lead painter order
- Artwork / Overlay / Skeleton views
- joint rotation sliders
- first viewer-left jab motion test
- fist artwork intentionally still pending

Upload the contents of this folder to the root of the `Verba-Ferrum-Animation-Studio` GitHub Pages repository. `index.html` expects the `character/` folder beside it.

The joint anchors are provisional and inferred from overlap between extracted artwork pieces. This build is for integration and motion QA, not final production pivot certification.
